package Payments;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class NewTest {
	static WebDriver driver;
	private final String USER_AGENT = "Mozilla/5.0";
	String methodName="";
	StringBuilder sb=new StringBuilder(""); 

	@BeforeTest
	public void beforeTest() {

		try
		{
			
			adminFunction.setPropertyFile();			
			sb.append("<html><HEAD>");
			sb.append("<style type=\"text/css\">table.gridtable {	font-family: verdana,arial,sans-serif;	font-size:11px;	color:#333333;	border-width: 1px;	border-color: #666666;	border-collapse: collapse;}table.gridtable th {	border-width: 1px;	padding: 8px;	border-style: solid;	border-color: #666666;	background-color: #dedede;}table.gridtable td {	border-width: 1px;	padding: 8px;	border-style: solid;	border-color: #666666;	background-color: #ffffff;}</style>");
			sb.append("<p> RESULTS</p>");
			sb.append("<table class=\"gridtable\">");
			sb.append("  <tr>        <td> TestCase Name</td><td> Test Step Name</td>		<td> Status </td>                <td>ScreenShot</td></tr>");


		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void getAuthenticationToken() throws URISyntaxException, IOException {
		methodName=Thread.currentThread().getStackTrace()[1].getMethodName();;
		try{			

			String AuthorizationToken=adminFunction.generateAutho();
			String bo="{\"order\":{\"amountOfMoney\":{\"currencyCode\":\"USD\",\"amount\":2345},\"customer\":{\"billingAddress\":{\"countryCode\":\"US\"},\"merchantCustomerId\":2705}},\"hostedCheckoutSpecificInput\":{\"variant\":\"100\",\"locale\":\"en_GB\"}}";
			bo="{\"order\":{\"amountOfMoney\":{\"currencyCode\":\"USD\",\"amount\":2345},\"customer\":{\"billingAddress\":{\"countryCode\":\"US\"},\"merchantCustomerId\":2705}},\"hostedCheckoutSpecificInput\":{\"variant\":\"100\",\"locale\":\"en_GB\"}}";
			String url="https://eu.sandbox.api-ingenico.com/v1/2705/hostedcheckouts";
			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(url);
			// add header
			post.setHeader("X-GCS-RequestId", "f6b40b22-c13e-4e0c-9b84-f9dd5dba1f2f");
			post.setHeader("Content-Type", "application/json");
			post.setHeader("Date", "Mon, 01 Oct 2018 17:16:24 GMT");
			post.setHeader("Authorization", AuthorizationToken);
			post.setHeader("X-GCS-MessageId", "32915676-02b4-484b-a4bf-3c7c784f98dx");
			StringEntity entity = new StringEntity(bo);
			entity.setContentType("application/json;");
			post.setEntity(entity);
			HttpResponse response = client.execute(post);
			System.out.println("Response code "+response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode()==201)
			{
				BufferedReader rd = new BufferedReader(
						new InputStreamReader(response.getEntity().getContent()));
				StringBuffer result = new StringBuffer();
				String line = "";
				while ((line = rd.readLine()) != null) {
					result.append(line);	}
				System.out.println("Data "+result.toString());
				ObjectMapper mapper = new ObjectMapper();
				String newresult=result.toString();
				JsonNode root = mapper.readTree(newresult);
				String node1=root.path("partialRedirectUrl").toString();
				System.out.println(node1);
				node1=node1.replaceAll("\"", "");
				node1=node1.replaceAll("pay1", "https://payment");
				System.out.println(node1);
				String fileName=System.getProperty("user.dir")+"\\payLink.txt";
				BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
				writer.write(node1);
				writer.close();
				adminFunction.passResultAPI(methodName,"FetchPartialLinkThroughtAPI", sb);
				
			}
			else adminFunction.failResult(methodName,"FetchPartialLinkThroughtAPI", sb);
			

		}
		catch (Exception e)
		{
			adminFunction.failResult(methodName,"FetchPartialLinkThroughtAPI",sb);
			e.printStackTrace();
		}

	}

	@Test
	public void paymentAutomation() throws URISyntaxException, IOException {
		methodName=Thread.currentThread().getStackTrace()[1].getMethodName();;
		try{
			String fileName=System.getProperty("user.dir")+"\\payLink.txt";

			Scanner scanner = new Scanner(Paths.get(fileName), StandardCharsets.UTF_8.name());
			String content = scanner.useDelimiter("\\A").next();
			scanner.close();

			driver=adminFunction.launchBrowser("chrome",content);
			String result=adminFunction.completePayment(driver,methodName,sb);
			if (result.equalsIgnoreCase("PASS"))
			{
				adminFunction.passResult(methodName,"COMPLETE TEST CASE", sb);
			}
			
			else
			{
				adminFunction.failResult(methodName,"COMPLETE TEST CASE", sb);
			}
			
			



		}
		catch (Exception e)
		{
			e.printStackTrace();
			adminFunction.failResult(methodName,"COMPLETE TEST CASE", sb);
		}

	}


	@AfterTest
	public void afterTest() {

		driver.quit();
		try{
		File file1 = new File(System.getProperty("user.dir")+"\\indexNew.html");

		if (!file1.exists()) {
			file1.createNewFile();}
		FileWriter fw=null;
		fw = new FileWriter(file1.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(sb.toString());

		bw.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
