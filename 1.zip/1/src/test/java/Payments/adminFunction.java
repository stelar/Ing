package Payments;

import org.openqa.selenium.By;		
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.FileUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import Payments.Keywords;


public class adminFunction extends Keywords {
	static WebDriver driver = null;
	static Keywords key=new Keywords();
	public static Properties propAdminPaths = new Properties();
	public static Properties propAdminInput = new Properties();
	
	public static void setPropertyFile() throws FileNotFoundException, IOException {
		propAdminPaths.load(new FileInputStream(System.getProperty("user.dir")+File.separator+"src"+File.separator+"main"+File.separator+"java"+File.separator+"Payments"+File.separator+"or.properties"));
		propAdminInput.load(new FileInputStream(System.getProperty("user.dir")+File.separator+"src"+File.separator+"main"+File.separator+"java"+File.separator+"Payments"+File.separator+"dinerPayment.properties"));
	}
	
	 public static Properties getAdminUIPaths(){
   	  return propAdminPaths;
     }
	 
	 public static Properties getAdminUIInput(){
	   	  return propAdminInput;
	     }
	public static String generateAutho() throws IOException
	{


		try {
			System.out.println(System.getProperty("user.dir"));
			String fileName=System.getProperty("user.dir")+"\\resp.txt";
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			StringBuilder stringBuilder = new StringBuilder();
			String line = null;
			String ls = System.getProperty("line.separator");
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}
			reader.close();
			String content = stringBuilder.toString();
			System.out.println(content);
			System.out.println("+++++++");
			String key = "9Z+P8ov5aKJD/qxZZzbOuhJR8DApww1ow75mTPjAxC0=";
			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(key.getBytes(), "HmacSHA256");
			sha256_HMAC.init(secret_key);
			content="POST\napplication/json\nMon, 01 Oct 2018 17:16:24 GMT\nx-gcs-messageid:32915676-02b4-484b-a4bf-3c7c784f98dx\nx-gcs-requestid:f6b40b22-c13e-4e0c-9b84-f9dd5dba1f2f\n/v1/2705/hostedcheckouts\n";
			String hash = Base64.encodeBase64String(sha256_HMAC.doFinal(content.getBytes()));
			System.out.println(hash);
			System.out.println(hash.toString());
			String h= hash.toString();
			h="GCS v1HMAC:a873dffad94bcd8d:"+h;
			return h;
		}
		catch (NoSuchAlgorithmException e) {return "error";}
		catch (InvalidKeyException e) {return "error";}

	}

	public static WebDriver launchBrowser(String browser,String url) throws FileNotFoundException, IOException, InterruptedException {
		if(browser.equalsIgnoreCase("Firefox")) {
			//DesiredCapabilities capabilities = DesiredCapabilities.firefox();
			//System.setProperty("webdriver.firefox.marionette", "false");
			System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+File.separator+"Drivers"+File.separator+"geckodriver.exe");
			//capabilities.setCapability("marionette", true);
			System.out.println(System.getProperty("user.dir")+File.separator+"Drivers"+File.separator+"geckodriver.exe");
			DesiredCapabilities capabilities=DesiredCapabilities.firefox();
			capabilities.setCapability("marionette", true);

			WebDriver driver = new FirefoxDriver(capabilities);
			driver.manage().window().maximize();
			driver.get(url);
			return driver;
		}

		else if (browser.equalsIgnoreCase("Chrome")) { 

			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+File.separator+"Drivers"+File.separator+"chromedriver.exe");
			Map<String, Object> prefs = new HashMap<String, Object>(); 
			prefs.put("profile.default_content_settings.popups", 0);
			//prefs.put("download.default_directory",Constants.BROWSER_DOWNLOAD_PATH);	
			prefs.put("download.prompt_for_download", "false");
			ChromeOptions options = new ChromeOptions();		
			options.setHeadless(true);
			options.addArguments("ignore-certificate-errors");
//			options.setExperimentalOption("prefs",prefs);
//			options.addArguments("test-type");
//			options.addArguments("start-maximized");
			options.addArguments("headless");
//			options.addArguments("disable-gpu");
//			options.addArguments("window-size=1980,960");
//			options.addArguments("screenshot");
//			DesiredCapabilities caps = DesiredCapabilities.chrome();
//			caps.setCapability(ChromeOptions.CAPABILITY, options);
			DesiredCapabilities handlSSLErr = DesiredCapabilities.chrome ();       
			handlSSLErr.setCapability (CapabilityType.ACCEPT_SSL_CERTS, false);
			handlSSLErr.setCapability (CapabilityType.ACCEPT_INSECURE_CERTS, true);
			handlSSLErr.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(handlSSLErr);    
			driver.get(url);
			Thread.sleep(5000);
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			String fileLocation= System.getProperty("user.dir")+"\\";
			FileUtils.copyFile(scrFile, new File(fileLocation+"name.png"));
			System.out.println("here");
			
			
		}
//		else if (browser.equalsIgnoreCase("phantom"))
//		{
//			 WebDriver driver = new HtmlUnitDriver();
//		}
//				
		return driver;
	}
	public static String getHostedCheckoutBody(WebDriver driver) throws IOException
	{


		try {
			
			String fileName=System.getProperty("user.dir")+"\\bod.txt";
			Scanner scanner = new Scanner(Paths.get(fileName), StandardCharsets.UTF_8.name());
			String content = scanner.useDelimiter("\\A").next();
			scanner.close();
			
			return content;
		}
		catch (Exception e){
			return "error";
		}

	}
	
	public static String completePayment(WebDriver driver, String methodName, StringBuilder sb) throws InterruptedException, IOException
	{
		String result ="";
		String cardNo=getAdminUIInput().getProperty("cardNo");
		String cvv=getAdminUIInput().getProperty("cvv");
		String date=getAdminUIInput().getProperty("date");
		System.out.println(adminFunction.getAdminUIPaths().getProperty("cvvInput"));
		String cvvInput=adminFunction.getAdminUIPaths().getProperty("cvvInput");		
		String dateInput=adminFunction.getAdminUIPaths().getProperty("dateInput");
		String payButton=adminFunction.getAdminUIPaths().getProperty("payButton");
		String successpath=adminFunction.getAdminUIPaths().getProperty("successpath");
		String dinersClubPath=adminFunction.getAdminUIPaths().getProperty("dinersClubPath");
		String carnumber=adminFunction.getAdminUIPaths().getProperty("carnumber");
		String orderPath=adminFunction.getAdminUIPaths().getProperty("orderPath");
		try {
			result=key.waitForElement(methodName,driver, dinersClubPath, 20,sb);
			if(!result.equalsIgnoreCase("pass"))
				return "fail";
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		result=key.click(methodName,driver, dinersClubPath,sb);
		if(!result.equalsIgnoreCase("pass"))
			return "fail";
		
		try {
			result=key.waitForElement(methodName,driver, orderPath, 20,sb);
			if(!result.equalsIgnoreCase("pass"))
				return "fail";
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.sleep(2000);
		
		result=key.sendText(methodName,driver, carnumber, cardNo,sb);
		if(!result.equalsIgnoreCase("pass"))
			return "fail";
		Thread.sleep(5000);
		result=key.sendText(methodName,driver, dateInput, date,sb);
		if(!result.equalsIgnoreCase("pass"))
			return "fail";
		result=key.sendText(methodName,driver, cvvInput, cvv,sb);
		if(!result.equalsIgnoreCase("pass"))
			return "fail";
		Thread.sleep(2000);
		result=key.click(methodName,driver, payButton,sb);
		if(!result.equalsIgnoreCase("pass"))
			return "fail";
		Thread.sleep(5000);				
		result=key.waitForElement(methodName,driver, successpath, 20,sb);
		if(!result.equalsIgnoreCase("pass"))
			return "fail";
		return "PASS";
	}
	public static void passResult(String methodName, String TestStep, StringBuilder sb) throws IOException

	{
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		String screenShotName=(dateFormat.format(date));
		TakeScreenshot(screenShotName);
		sb.append("<tr><td>"+methodName+"</td><td>"+TestStep+"</td><td style=\"background-color: #00FF00\">Pass</td><td>"+"<a href="+screenShotName+".png>Attachment</a></td></tr>");
	}
	
	public static void passResultAPI(String methodName, String TestStep, StringBuilder sb) throws IOException

	{
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		String screenShotName=(dateFormat.format(date));
		
		sb.append("<tr><td>"+methodName+"</td><td>"+TestStep+"</td><td style=\"background-color: #00FF00\">Pass</td></tr>");
	}
	public static void failResult(String methodName, String TestStep,StringBuilder sb) throws IOException

	{
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		String screenShotName=(dateFormat.format(date));
		TakeScreenshot(screenShotName);
		sb.append("<tr><td>"+methodName+"</td><td>"+TestStep+"</td><td style=\"background-color: #FF0000\">FAIL</td><td>"+"<a href="+screenShotName+".png>ToImage</a></td></tr>");
	}
	public static void TakeScreenshot(String name) throws IOException
	{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		String fileLocation= System.getProperty("user.dir")+"\\";
		FileUtils.copyFile(scrFile, new File(fileLocation+name+".png"));
	}
}
